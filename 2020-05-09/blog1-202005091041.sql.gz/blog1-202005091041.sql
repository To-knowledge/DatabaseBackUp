-- MySQL dump 10.13  Distrib 5.7.30, for Linux (aarch64)
--
-- Host: localhost    Database: blog1
-- ------------------------------------------------------
-- Server version	5.7.30-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_blog`
--

DROP TABLE IF EXISTS `t_blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_blog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appreciation` bit(1) NOT NULL,
  `commentabled` bit(1) NOT NULL,
  `content` longtext,
  `create_time` datetime DEFAULT NULL,
  `first_picture` varchar(255) DEFAULT NULL,
  `flag` varchar(255) DEFAULT NULL,
  `published` bit(1) NOT NULL,
  `recommend` bit(1) NOT NULL,
  `share_statement` bit(1) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `views` int(11) DEFAULT NULL,
  `type_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK292449gwg5yf7ocdlmswv9w4j` (`type_id`),
  KEY `FK8ky5rrsxh01nkhctmo7d48p82` (`user_id`),
  CONSTRAINT `FK292449gwg5yf7ocdlmswv9w4j` FOREIGN KEY (`type_id`) REFERENCES `t_type` (`id`),
  CONSTRAINT `FK8ky5rrsxh01nkhctmo7d48p82` FOREIGN KEY (`user_id`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_blog`
--

LOCK TABLES `t_blog` WRITE;
/*!40000 ALTER TABLE `t_blog` DISABLE KEYS */;
INSERT INTO `t_blog` VALUES (1,_binary '',_binary '','# 数据库（上篇：操作）\r\n\r\n重点部分：\r\n**数据库设计范式、多表关系、事务、java操作数据库等**\r\n\r\n数据库，存储和管理数据的仓库，它是一个文件系统，可以持久化存储数据，它采用统一的操作方式管理数据（SQL）。\r\n\r\n## Structure Query Language(SQL)\r\n一种操作所有关系型数据库的语言，由DDL（操作数据库、表）、DML（增删改表中数据）、DQL（查表中数据）、QCL（权限管理）四类构成。\r\n## 表查询（SELECT * FROM  表名）\r\n##### 排序查询\r\n```sql\r\nORDER BY \'字段\' ASC/DESC;\r\n```\r\n`ASC`代表升序，`DESC`代表降序，可重复选择多个字段，字段越靠前，优先级越高。参考：\r\n\r\n```sql\r\nSELECT * FROM student ORDER BY math ASC, Chinese DESC;\r\n```\r\n##### 聚合函数\r\n五大聚合函数\r\n```sql\r\nCOUNT(); MAX(); MIN(); SUM(); AVG();\r\n```\r\n##### 分组查询\r\n```sql\r\nGROUP BY \'字段\';\r\n```\r\n此时，`SELECT`后必须是分组字段或者聚合函数。参考：\r\n```sql\r\nSELECT sex FROM student GROUP BY sex;\r\n```\r\n这里分组之前可以加`WHERE条件`，WHERE中不可以有聚合函数，分组之后可以加`HAVING条件`。参考：\r\n```sql\r\nSELECT AVG(math) FROM student WHERE math > 60 GROUP BY sex HAVING(math) > 70;\r\n```\r\n##### 分页查询\r\n\r\n```sql\r\nLIMIT a, b;\r\n```\r\n\r\n`a`代表从第a条开始，`b`代表查询b条记录。\r\n\r\n##### 模糊条件查询\r\n\r\n```\r\nWHERE name LIKE \"%化%\"; --以及\"_化_\"\r\n```\r\n\r\n`%`指代多个字符，`_`指代单个任意字符。\r\n\r\n##### 汇总\r\n\r\n```sql\r\nSELECT\r\n	字段列表\r\nFROM\r\n	表名\r\nWHERE\r\n	条件列表\r\nGROUP BY\r\n	分组字段\r\nWHERE\r\n	分组之后的条件\r\nORDER BY\r\n	排序字段 ASC / DESC\r\nLIMIT\r\n	开始条号，几条；\r\n```\r\n\r\n## 约束\r\n\r\n用于对表中数据进行限定（创建表时约束）\r\n\r\n##### 非空约束\r\n\r\n```sql\r\nNOT NULL;\r\n```\r\n\r\n##### 唯一约束\r\n\r\n```sql\r\nUNIQUE;\r\n```\r\n\r\n##### 主键约束非空且唯一\r\n\r\n```sql\r\nPRIMARY KEY;\r\n```\r\n\r\n一张表只能有一个主键，主键是表中记录的唯一标识，主键可以设定为自动增长模式。\r\n\r\n##### 外键约束\r\n\r\n```sql\r\nFOREIGN KEY;\r\n```\r\n\r\n数据库有冗余，需要拆分表，拆开的表用外键关联，参考员工与部门。外键语法：\r\n\r\n```sql\r\nALTER TABLE 表名 ADD CONSTRAINT 外键名称 FOREIGN KEY 外键列名称 REFERENCE 主表名称（主表列名称）\r\nON UPDATE / DELETE CASCASE;\r\n```\r\n\r\n尾部用于表征级联更新与级联删除（慎用）。\r\n\r\n## 多表之间的关系\r\n\r\n##### 一对一\r\n\r\n通常是一张表，或者在任一方添加外键，并让外键唯一。\r\n\r\n##### 多以一（一对多）\r\n\r\n通过外键级联，在多的一方添加外键。举例：博客n->分类1\r\n\r\n##### 多对多\r\n\r\n添加中间表，其至少包含两个字段，左外键与右外键，二者构成联合主键。举例：博客n->标签m\r\n\r\n## 设计范式\r\n\r\n越高的范式对应的数据库冗余越小。\r\n\r\n##### 第一范式\r\n\r\n每一列都是不可分割的原子项\r\n\r\n##### 第二范式\r\n\r\n在第一范式的基础上，消除非码属性对于码属性的<font color=red>**部分依赖**</font>\r\n\r\n<font color=red>**码属性**</font>是指表中的一个属性组，给其它属性完全依赖\r\n\r\n##### 第三范式\r\n\r\n在第二范式的基础上，消除非主属性之间的相互依赖，即消除<font color=red>**传递依赖**</font>\r\n\r\n## 数据库的备份与还原\r\n\r\n```sql\r\nmysqldump -u*** -p*** db1 >备份路径;\r\nsource .sql文件;\r\n```\r\n\r\n## 多表查询\r\n\r\n```sql\r\nSELECT * FROM emp, dept;\r\n```\r\n\r\n笛卡尔积，集合A与B的所有元素组合。\r\n\r\n##### 内连接查询(交集)\r\n\r\n```sql\r\nSELECT * FROM emp t1 (INNER) JOIN dep t2 on t1.** = t2.**;\r\n```\r\n\r\n##### 外连接查询（左/右表+交集）\r\n\r\n```sql\r\n* FROM emp t1 (INNER) left / right JOIN dep t2 on t1.** = t2.**;\r\n```\r\n\r\n##### 子查询\r\n\r\n查询中嵌套查询（sql查询语句的结果集ResultSet）。\r\n\r\n## 事务\r\n\r\n并发环境下，事务的隔离性很难保证，出现并发一致性问题。\r\n\r\n脏读，不可重复读，幻影读。\r\n\r\n## JDBC(Java database connectivity)\r\n\r\nJDBC是一套Java接口，定义了操作所有关系型数据库的规范，由各数据库厂商来提供驱动jar包，即接口实现类。\r\n##### java操作数据库的具体实现流程\r\n\r\n1. 导入驱动jar包；\r\n\r\n2. 注册驱动（内部实现是加载DriverManager类里面的静态代码块，其中包含一个registerDriver()方法）；\r\n\r\n   ```java\r\n   Class.forname(\"com.mySQL.jdbc.Driver\");\r\n   ```\r\n\r\n3. 建立数据库连接；\r\n\r\n   ```java\r\n   DriverManager.getConnection(\"jdbc:mysql://ipaddress:端口/数据库名称\");\r\n   ```\r\n\r\n4. 定义sql语句（字符串形式）；\r\n\r\n5. 创建执行sql的Statement对象<通过Connection对象的方法创建>（sql注入问题），采用PreparedStatement对象，传参防止sql注入导致的安全问题；\r\n\r\n6. 执行sql，返回ResultSet；\r\n\r\n   ```java\r\n   excuteUpdate();	//执行增删改操作\r\n   excuteQuery();	//执行查操作\r\n   ```\r\n\r\n7. 释放资源，Statement以及Connection对象。\r\n\r\n##### JDBC管理事务\r\n\r\n   通过Connection对象方法设置事务的开启、提交以及回滚：\r\n\r\n   ```java\r\n   setAutoCommit(boolean autoCommit);	//设置为false开启事务\r\n   commit();	//提交事务\r\n   rollback();	//回滚事务\r\n   ```\r\n\r\n## 数据库连接池\r\n\r\n存放Connection对象的容器，其优点是避免频繁地申请释放连接资源，导致性能低效。目前著名的有两种，C3P0以及Druid，此处的Connection.close()方法是归还连接对象，而不是释放连接。\r\n\r\n## Spring JDBC Template\r\n\r\n省去开发人员自己申请连接，释放连接，开发人员只需要关注数据库本身的具体操作即可。','2020-05-08 14:33:36','https://picsum.photos/1000/600?image=1000','原创',_binary '',_binary '',_binary '','数据库上篇：SQL操作','2020-05-08 21:21:14',10,2,1),(2,_binary '\0',_binary '\0','### 解题思路\r\n1、定义数组minCostTickets；\r\n2、days数组中前i项构成的旅行数组所需要的最小票价记为minCostTickets[i+1],则有\r\n```java\r\nminCostTickets[i+1] = Math.min(\r\n                    Math.min(costs[0] + minCostTickets[end1],\r\n                             costs[1] + minCostTickets[end7]),\r\n                    costs[2] + minCostTickets[end30]);\r\n```\r\n其中end1,end7,end30通过以下逻辑求得，本质就是**花多少钱，除去对应的多少天**：\r\n```java\r\n            while(end1 > 0 && days[i] - days[end1 - 1] < 1) end1--;\r\n            while(end7 > 0 && days[i] - days[end7 - 1] < 7) end7--;\r\n            while(end30 > 0 && days[i] - days[end30 - 1] < 30) end30--;\r\n```\r\n注记：此处minCostTickets[0] = 0，用于边界处理。\r\n\r\n### 代码\r\n\r\n```java\r\nclass Solution {\r\n    //自底向上\r\n    public int mincostTickets(int[] days, int[] costs) {\r\n        int end1 = 0;\r\n        int end7 = 0;\r\n        int end30 = 0;\r\n        //定义一个记忆数组\r\n        int[] minCostTickets = new int[days.length + 1];\r\n        for(int i = 0; i < days.length; i++){\r\n            end1 = i + 1;\r\n            end7 = i + 1;\r\n            end30 = i + 1;\r\n            //防止数组越界\r\n            while(end1 > 0 && days[i] - days[end1 - 1] < 1) end1--;\r\n            while(end7 > 0 && days[i] - days[end7 - 1] < 7) end7--;\r\n            while(end30 > 0 && days[i] - days[end30 - 1] < 30) end30--;\r\n            //状态转移方程\r\n            minCostTickets[i+1] = Math.min(\r\n                    Math.min(costs[0] + minCostTickets[end1],\r\n                             costs[1] + minCostTickets[end7]),\r\n                    costs[2] + minCostTickets[end30]);\r\n        }\r\n        return minCostTickets[days.length];\r\n    }\r\n}\r\n```','2020-05-08 15:19:03','https://picsum.photos/1000/600?image=1016','原创',_binary '',_binary '',_binary '\0','最低票价','2020-05-08 21:09:12',10,3,1),(3,_binary '',_binary '\0','### 题目描述\r\n在一个由 0 和 1 组成的二维矩阵内，找到只包含 1 的最大正方形，并返回其面积。\r\n\r\n输入:\r\n1 0 1 0 0\r\n\r\n1 0 1 1 1\r\n\r\n1 1 1 1 1\r\n\r\n1 0 0 1 0\r\n\r\n输出: 4\r\n\r\n### 解题思路\r\n以char数组中当前节点作为正方形的右下角，容易分析，\r\n\r\n若当前节点为\'0\'，则不可构成正方形，\r\n\r\n否则，其可以构成的正方形由以下三部分共同决定：\r\n\r\n1、当前节点正上方连续1的个数；\r\n\r\n2、当前节点正左方连续1的个数；\r\n\r\n3、当前节点左上方的最大正方形边长；\r\n\r\n上述三个变量取最小值，再加1，就是以当前节点作为正方形的右下角可构成的最大正方形边长。\r\n\r\n### 代码\r\n\r\n```java\r\nclass Solution {\r\n    public int maximalSquare(char[][] matrix) {\r\n        if(matrix.length == 0)  return 0;\r\n        //最大正方形\r\n        //定义三个dp二维数组\r\n        //1、用来记录当前元素与其上面连续1的个数\r\n        int[][] dpUp = new int[matrix.length+1][matrix[0].length+1];\r\n        //2、用来记录当前元素与其左面连续1的个数\r\n        int[][] dpLeft = new int[matrix.length+1][matrix[0].length+1];\r\n        //3、用来记录以当前元素为右角可构成的最大正方形边长\r\n        int[][] dpSqure = new int[matrix.length+1][matrix[0].length+1];\r\n        int result = 0;\r\n        for(int i = 0; i < matrix.length; i++){\r\n            for(int j = 0; j < matrix[i].length; j++){\r\n                if(matrix[i][j] == \'0\') continue;\r\n                dpUp[i+1][j+1] = dpUp[i][j+1] + 1;\r\n                dpLeft[i+1][j+1] = dpLeft[i+1][j] + 1;\r\n                dpSqure[i+1][j+1] = Math.min(dpUp[i][j+1],                                                                         Math.min(dpLeft[i+1][j], dpSqure[i][j])) + 1;\r\n                result = dpSqure[i+1][j+1] > result ? dpSqure[i+1][j+1] : result;\r\n            }\r\n        }\r\n        \r\n        return result*result;\r\n    }\r\n}\r\n```','2020-05-08 22:38:13','https://picsum.photos/1000/600?image=1015','原创',_binary '',_binary '',_binary '','最大正方形','2020-05-08 22:41:20',7,3,1),(4,_binary '',_binary '\0','### 题目描述\r\n实现 int sqrt(int x) 函数。\r\n\r\n计算并返回 x 的平方根，其中 x 是非负整数。\r\n\r\n由于返回类型是整数，结果只保留整数的部分，小数部分将被舍去。\r\n\r\n来源：力扣（LeetCode）\r\n\r\n\r\n### 解题思路\r\n1、在[0,x)区间进行二分查找，但此时需要注意，当x = 1时，答案已经不在区间中，需作为特例对待；\r\n\r\n2、二分的判定条件，需要使用除法，乘法会在x很大时，造成int越界。\r\n\r\n针对上述第一点，是否可以采用左闭右闭区间（回避x=1特例）呢，似乎改成闭区间会更加麻烦，欢迎大家说出自己的想法。\r\n\r\n### 代码\r\n\r\n```java\r\nclass Solution {\r\n    public int mySqrt(int x) {\r\n        //二分大法\r\n        //左闭右开\r\n        if(x == 1)  return 1;\r\n        int begin = 0;\r\n        int end = x;\r\n        int mid = 0;\r\n        while(end - begin >= 2){\r\n            mid = begin + ((end-begin)>>1);\r\n            //此处无需判断mid == 0，由于end - begin >= 2\r\n            if(mid <= x / mid)\r\n                begin = mid;\r\n            else\r\n                end = mid;\r\n        }\r\n        \r\n        return begin;\r\n    }\r\n}\r\n```','2020-05-09 08:45:45','https://picsum.photos/1000/600?image=1050','原创',_binary '',_binary '',_binary '','x的平方根','2020-05-09 08:45:45',2,3,1);
/*!40000 ALTER TABLE `t_blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_blog_tags`
--

DROP TABLE IF EXISTS `t_blog_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_blog_tags` (
  `blogs_id` bigint(20) NOT NULL,
  `tags_id` bigint(20) NOT NULL,
  KEY `FK5feau0gb4lq47fdb03uboswm8` (`tags_id`),
  KEY `FKh4pacwjwofrugxa9hpwaxg6mr` (`blogs_id`),
  CONSTRAINT `FK5feau0gb4lq47fdb03uboswm8` FOREIGN KEY (`tags_id`) REFERENCES `t_tag` (`id`),
  CONSTRAINT `FKh4pacwjwofrugxa9hpwaxg6mr` FOREIGN KEY (`blogs_id`) REFERENCES `t_blog` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_blog_tags`
--

LOCK TABLES `t_blog_tags` WRITE;
/*!40000 ALTER TABLE `t_blog_tags` DISABLE KEYS */;
INSERT INTO `t_blog_tags` VALUES (2,5),(1,4),(3,5),(4,5);
/*!40000 ALTER TABLE `t_blog_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_comment`
--

DROP TABLE IF EXISTS `t_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_comment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `blog_id` bigint(20) DEFAULT NULL,
  `parent_comment_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKke3uogd04j4jx316m1p51e05u` (`blog_id`),
  KEY `FK4jj284r3pb7japogvo6h72q95` (`parent_comment_id`),
  CONSTRAINT `FK4jj284r3pb7japogvo6h72q95` FOREIGN KEY (`parent_comment_id`) REFERENCES `t_comment` (`id`),
  CONSTRAINT `FKke3uogd04j4jx316m1p51e05u` FOREIGN KEY (`blog_id`) REFERENCES `t_blog` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_comment`
--

LOCK TABLES `t_comment` WRITE;
/*!40000 ALTER TABLE `t_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_tag`
--

DROP TABLE IF EXISTS `t_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_tag`
--

LOCK TABLES `t_tag` WRITE;
/*!40000 ALTER TABLE `t_tag` DISABLE KEYS */;
INSERT INTO `t_tag` VALUES (4,'database'),(5,'leetcode'),(7,'spring');
/*!40000 ALTER TABLE `t_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_type`
--

DROP TABLE IF EXISTS `t_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_type`
--

LOCK TABLES `t_type` WRITE;
/*!40000 ALTER TABLE `t_type` DISABLE KEYS */;
INSERT INTO `t_type` VALUES (2,'数据库'),(3,'算法'),(4,'框架');
/*!40000 ALTER TABLE `t_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `update_tine` datetime DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` VALUES (1,'https://i.picsum.photos/id/104/100/100.jpg',NULL,NULL,'one','123456',NULL,NULL,'xiaoyuquan');
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-09 10:41:25
